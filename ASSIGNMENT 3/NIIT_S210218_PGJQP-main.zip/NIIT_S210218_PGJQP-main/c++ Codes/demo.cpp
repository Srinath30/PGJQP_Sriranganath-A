//preprocessor directive
#include<iostream>
using namespace std;
class first_Program
{
  public: void display()
  {
      cout<<"Welcome to Niit ";
  }
};
int main() //main is the entry point of application
{
  first_Program obj;
  obj.display();
}
