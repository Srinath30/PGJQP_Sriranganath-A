package com.newtechbookstore.controller;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.newtechbookstore.dao.RegisterDao;
import com.newtechbookstore.dao.impl.RegisterDaoImpl;
import com.newtechbookstore.model.Customer;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userid;
		String firstname;
		String lastname;
		String gender;
		String dob;
        String Address;
		String phone;
		String email;
		String password;
		int zip;
		try {
			userid = request.getParameter("userid");
			firstname = request.getParameter("fname");
			lastname = request.getParameter("lname");
			gender = request.getParameter("gender");
			dob = request.getParameter("dob");
			Date dateOfBirth = new SimpleDateFormat("dd/MM/yyyy").parse(dob);
			Address= request.getParameter("Address");
			phone = request.getParameter("phone");
			email = request.getParameter("email");
			password = request.getParameter("password");
			RegisterDao rdao = new RegisterDaoImpl();
			Customer c = new Customer();
	        c.setUserid(userid);
			c.setFirstname(firstname);
			c.setLastname(lastname);
			c.setGender(gender);
			c.setDob(dateOfBirth);
			c.setCustomerAddress(Address);
	        c.setPhone(phone);
			c.setEmail(email);
			c.setPassword(password);
			if (rdao.register(c)) {
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}

