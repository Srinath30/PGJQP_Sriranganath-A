package com.book.model;
import java.io.Serializable;

import javax.persistence.GeneratedValue;
import javax.persistence.Id;

import org.hibernate.annotations.GenericGenerator;


public class Book implements Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int BookID;
	private	String Bookname;
	private	String Author;
	private	String Edition;
	private	String Category;
	private  String Publisher;
	private	String PublishingYear;
	private	String Price;
	private	String Quantity;

    public Book(){
    }

	

	public int getBookID() {
		return BookID;
	}



	public void setBookID(int bookID) {
		BookID = bookID;
	}



	public String getBookname() {
		return Bookname;
	}

	public void setBookname(String bookname) {
		Bookname = bookname;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		this.Author = author;
	}

	public String getEdition() {
		return Edition;
	}

	public void setEdition(String edition) {
		Edition = edition;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getPublisher() {
		return Publisher;
	}

	public void setPublisher(String publisher) {
		Publisher = publisher;
	}

	public String getPublishingYear() {
		return PublishingYear;
	}

	public void setPublishingYear(String publishingYear) {
		PublishingYear = publishingYear;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}

	public String getQuantity() {
		return Quantity;
	}

	public void setQuantity(String quantity) {
		Quantity = quantity;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}


	
}