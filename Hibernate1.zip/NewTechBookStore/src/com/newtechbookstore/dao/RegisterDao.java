package com.newtechbookstore.dao;

import com.newtechbookstore.model.Customer;

public interface RegisterDao {
	boolean register(Customer c);
}

