package com.book.controller;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.book.model.Book;
import com.book.dao.RegisterDao;
import com.book.dao.impl.RegisterDaoImpl;
import com.book.model.Book;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int BookID = 0;
		String Bookname;
		String Author;
		String Edition;
		String Category;
        String Publisher;
		String PublishingYear;
		String Price;
		String Quantity;
	
		try {
			 Bookname = request.getParameter("Bookname");
			 Author = request.getParameter("Author");
			 Edition = request.getParameter("Edition");
			 Category = request.getParameter("Category");
			 Publisher =request.getParameter("Publisher");
			 PublishingYear= request.getParameter("PublishingYear");
			 Price = request.getParameter("Price");
			 Quantity = request.getParameter("Quantity");
			
			RegisterDao rdao = new RegisterDaoImpl();
			Book b = new Book();
	         b.setBookID(BookID);
	         b.setBookname(Bookname);
	         b.setAuthor(Author);
	         b.setEdition(Edition);
	         b.setCategory(Category);
	         b.setPublisher(Publisher);
	         b.setPublishingYear(PublishingYear);
	         b.setPrice(Price);
	         b.setQuantity(Quantity);
	         if (rdao.register(b)) {
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
