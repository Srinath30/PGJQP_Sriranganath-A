package com.book.dao;

import com.book.model.Book;


public interface RegisterDao {
	boolean register(Book b);
}
