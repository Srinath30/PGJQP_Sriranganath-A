package com.book.dao;

import java.util.List;

import com.book.model.Book;

public interface BookDao {

	Book getBookByName(String bookName);
	List<Book> getAllBooks();
}
