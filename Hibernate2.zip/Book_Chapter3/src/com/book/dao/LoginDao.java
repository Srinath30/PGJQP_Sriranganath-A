package com.book.dao;

import com.book.model.Student;

public interface LoginDao {

	Student validUser(String username,String password);
	
}
