package com.book.dao;

import com.book.model.Student;

public interface RegisterDao {
boolean register(Student s);
}
