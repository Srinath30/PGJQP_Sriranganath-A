package com.book.model;

import java.io.Serializable;

public class Book implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private int BookId;
	private String BookName,Category,Author;
	private double BookFee;
	public Book() {

	}
	
	public int getBookId() {
		return BookId;
	}

	public void setBookId(int bookId) {
		BookId = bookId;
	}

	public String getBookName() {
		return BookName;
	}

	public void setBookName(String bookName) {
		BookName = bookName;
	}

	public String getCategory() {
		return Category;
	}

	public void setCategory(String category) {
		Category = category;
	}

	public String getAuthor() {
		return Author;
	}

	public void setAuthor(String author) {
		Author = author;
	}

	public double getBookFee() {
		return BookFee;
	}

	public void setBookFee(double bookFee) {
		BookFee = bookFee;
	}

	



	
	
	
}
