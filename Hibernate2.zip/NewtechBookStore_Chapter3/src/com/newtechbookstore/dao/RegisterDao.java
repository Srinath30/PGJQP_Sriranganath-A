package com.newtechbookstore.dao;

import com.newtechbookstore.model.Student;

public interface RegisterDao {
boolean register(Student s);
}

