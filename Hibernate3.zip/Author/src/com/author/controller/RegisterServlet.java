package com.author.controller;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.author.model.Author;
import com.author.dao.RegisterDao;
import com.author.dao.impl.RegisterDaoImpl;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		int AuthorID = 0;
		String Authorname;
		String Gender;
		String dob;
		String Address;
        String Contactno;
        String email;
		String Nationality;
	
	
		try {
			Authorname = request.getParameter("Authorname");
			Gender = request.getParameter("Gender");
			dob = request.getParameter("dob");
			Date dateOfBirth = new SimpleDateFormat("dd/MM/yyyy").parse(dob);
			Address = request.getParameter("Address");
			Contactno =request.getParameter("Contactno");
			email = request.getParameter("email");
			Nationality = request.getParameter("Nationality");
		    RegisterDao rdao = new RegisterDaoImpl();
	        Author a = new Author();
	         a.setAuthorID(AuthorID);
	         a.setAuthorname(Authorname);
	         a.setGender(Gender);
	     	 a.setDob(dateOfBirth);
	         a.setAddress(Address);
	         a.setContactno(Contactno);
	         a.setEmail(email);
	         a.setNationality(Nationality);
	         if (rdao.register(a)) {
				RequestDispatcher rd = request.getRequestDispatcher("success.jsp");
				rd.forward(request, response);
			} else {
				RequestDispatcher rd = request.getRequestDispatcher("error.jsp");
				rd.forward(request, response);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		}

	}

}
