package com.author.dao;

import com.author.model.Author;


public interface RegisterDao {
	boolean register(Author a);
}
