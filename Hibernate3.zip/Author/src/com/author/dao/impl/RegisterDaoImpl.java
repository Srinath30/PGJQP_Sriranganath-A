package com.author.dao.impl;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import com.author.dao.RegisterDao;
import com.author.model.Author;
import com.author.util.HibernateUtil;

public class RegisterDaoImpl implements RegisterDao {

	@Override
	public boolean register(Author a) {
		SessionFactory sf=HibernateUtil.getSessionFactory();
		try
		{
			Session session=sf.openSession();
			Transaction tx=session.beginTransaction();
			session.save(a);
			session.flush();
			tx.commit();
			return true;
		}
		catch(Exception ex)
		{
			ex.printStackTrace();
			return false;
		}
	}


}
