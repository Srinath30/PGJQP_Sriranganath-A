package com.author.model;
import java.io.Serializable;
import java.util.Date;




public class Author implements Serializable {


     /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private int AuthorID;
	private	String Authorname;
	private	String Gender;
	private	Date dob;
	private	String Address;
	private  String Contactno;
	private  String email;
	private	String Nationality;

    public Author(){
    }

	



	public int getAuthorID() {
		return AuthorID;
	}





	public void setAuthorID(int authorID) {
		AuthorID = authorID;
	}





	public String getAuthorname() {
		return Authorname;
	}





	public void setAuthorname(String authorname) {
		Authorname = authorname;
	}





	public String getGender() {
		return Gender;
	}





	public void setGender(String gender) {
		Gender = gender;
	}





	 public Date getDob() {
	        return this.dob;
	    }
	    
	    public void setDob(Date dob) {
	        this.dob = dob;
	    }





	public String getAddress() {
		return Address;
	}





	public void setAddress(String address) {
		Address = address;
	}





	public String getContactno() {
		return Contactno;
	}





	public void setContactno(String contactno) {
		Contactno = contactno;
	}





	public String getEmail() {
		return email;
	}





	public void setEmail(String email) {
		this.email = email;
	}





	public String getNationality() {
		return Nationality;
	}





	public void setNationality(String nationality) {
		Nationality = nationality;
	}





	public static long getSerialversionuid() {
		return serialVersionUID;
	}







	
}