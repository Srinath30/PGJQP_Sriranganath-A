package com.customer.dao;

import java.util.List;

import com.customer.model.Course;

public interface CourseDao {

	Course getCourseByName(String courseName);
	List<Course> getAllCourses();
}
