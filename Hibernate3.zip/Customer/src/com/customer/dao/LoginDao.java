package com.customer.dao;

import com.customer.model.Student;

public interface LoginDao {

	Student validUser(String username,String password);
	
}
