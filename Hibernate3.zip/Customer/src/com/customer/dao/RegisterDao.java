package com.customer.dao;

import com.customer.model.Student;

public interface RegisterDao {
boolean register(Student s);
}
