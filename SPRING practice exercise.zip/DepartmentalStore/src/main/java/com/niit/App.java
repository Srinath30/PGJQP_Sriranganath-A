package com.niit;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.chapter2.Product;
import com.niit.chapter2.Customer;
import com.niit.chapter2.Order;

public class App 
{
    public static void main( String[] args )
    {
ApplicationContext ac = new ClassPathXmlApplicationContext("spring-config.xml");
Customer cust = (Customer)ac.getBean("Customer");
Product prod=(Product)ac.getBean("Product");
Order order=(Order)ac.getBean("Order");
System.out.println("The Values of Customer are:");
System.out.println(cust.getFirstName());
System.out.println(cust.getMiddleName());
System.out.println(cust.getLastName());
System.out.println(cust.getDateOfBirth());
System.out.println(cust.getMonthOfBirth());
System.out.println(cust.getMotherName());
System.out.println(cust.getEmailID());
System.out.println(cust.getGender());
System.out.println(cust.getMaritalStatus());
System.out.println(cust.getHouseNo());
System.out.println(cust.getStreetName());
System.out.println(cust.getState());
System.out.println(cust.getCity());
System.out.println(cust.getPincode());
System.out.println(cust.getPhone());
System.out.println(cust.getUserName());
System.out.println(cust.getPassword());
System.out.println("-------------------------");
System.out.println(prod.getProductID());
System.out.println(prod.getProductName());
System.out.println(prod.getProductAmount());
System.out.println(prod.getPaymentType());
System.out.println("-------------------------");
System.out.println(order.getOrders());
}
}