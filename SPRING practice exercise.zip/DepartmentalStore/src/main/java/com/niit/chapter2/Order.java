package com.niit.chapter2;

import java.io.Serializable;

public class Order implements Serializable {
private String orders;

public Order(String orders) {
	
	this.orders = orders;
}

public String getOrders() {
	return orders;
}

public void setOrders(String orders) {
	this.orders = orders;
}


}
