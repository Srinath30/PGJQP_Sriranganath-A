package com.niit.chapter2;

import java.io.Serializable;

public class Product implements Serializable {
	private String productID;
	private String productName;
	private double productAmount;
	private String paymentType;
	
	public Product() {
		
	}

	public Product(String productID, String productName, double productAmount, String paymentType) {
		super();
		this.productID = productID;
		this.productName = productName;
		this.productAmount = productAmount;
		this.paymentType = paymentType;
	}

	public String getProductID() {
		return productID;
	}

	public void setProductID(String productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getProductAmount() {
		return productAmount;
	}

	public void setProductAmount(double productAmount) {
		this.productAmount = productAmount;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	
	
	
	
}
