package com.niit;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.chapter2.Rooms;
import com.niit.chapter2.Customer;
import com.niit.chapter2.BookingDetails;

public class App 
{
    public static void main( String[] args )
    {
ApplicationContext ac = new ClassPathXmlApplicationContext("spring-config.xml");
Customer cust = (Customer)ac.getBean("Customer");
Rooms room=(Rooms)ac.getBean("Rooms");
BookingDetails bookingdetails=(BookingDetails)ac.getBean("BookingDetails");
System.out.println("The Values of Customer are:");
System.out.println(cust.getFirstName());
System.out.println(cust.getMiddleName());
System.out.println(cust.getLastName());
System.out.println(cust.getDateOfBirth());
System.out.println(cust.getMonthOfBirth());
System.out.println(cust.getMotherName());
System.out.println(cust.getEmailID());
System.out.println(cust.getGender());
System.out.println(cust.getMaritalStatus());
System.out.println(cust.getHouseNo());
System.out.println(cust.getStreetName());
System.out.println(cust.getState());
System.out.println(cust.getCity());
System.out.println(cust.getPincode());
System.out.println(cust.getPhone());
System.out.println(cust.getUserName());
System.out.println(cust.getPassword());
System.out.println("-------------------------");
System.out.println(room.getRoomNumber());
System.out.println(room.getRoomCheckIndate());
System.out.println(room.getBalanceAmount());
System.out.println(room.getPaymentType());
System.out.println("-------------------------");
System.out.println(bookingdetails.getBookedRooms());
}
}
