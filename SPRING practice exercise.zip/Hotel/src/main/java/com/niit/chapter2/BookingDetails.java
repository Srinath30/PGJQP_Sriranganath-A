package com.niit.chapter2;

import java.io.Serializable;

public class BookingDetails implements Serializable {
private double bookedRooms;

public BookingDetails(double bookedRooms) {

	this.bookedRooms = bookedRooms;
}

public double getBookedRooms() {
	return bookedRooms;
}

public void setBookedRooms(double bookedRooms) {
	this.bookedRooms = bookedRooms;
}

}