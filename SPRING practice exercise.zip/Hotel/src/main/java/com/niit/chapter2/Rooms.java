package com.niit.chapter2;

import java.io.Serializable;

public class Rooms implements Serializable {
private String roomNumber;
private String roomCheckIndate;
private double balanceAmount;
private String paymentType;

public Rooms() {
	
}

public Rooms(String roomNumber, String roomCheckIndate, double balanceAmount, String paymentType) {
	super();
	this.roomNumber = roomNumber;
	this.roomCheckIndate = roomCheckIndate;
	this.balanceAmount = balanceAmount;
	this.paymentType = paymentType;
}

public String getRoomNumber() {
	return roomNumber;
}

public void setRoomNumber(String roomNumber) {
	this.roomNumber = roomNumber;
}

public String getRoomCheckIndate() {
	return roomCheckIndate;
}

public void setRoomCheckIndate(String roomCheckIndate) {
	this.roomCheckIndate = roomCheckIndate;
}

public double getBalanceAmount() {
	return balanceAmount;
}

public void setBalanceAmount(double balanceAmount) {
	this.balanceAmount = balanceAmount;
}

public String getPaymentType() {
	return paymentType;
}

public void setPaymentType(String paymentType) {
	this.paymentType = paymentType;
}


}
