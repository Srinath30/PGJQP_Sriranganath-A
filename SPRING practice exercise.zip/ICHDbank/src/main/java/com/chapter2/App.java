package com.chapter2;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.chapter2.activity1.Account;
import com.chapter2.activity1.Customer;
import com.chapter2.activity1.FundTransfer;

public class App 
{
    public static void main( String[] args )
    {
ApplicationContext ac = new ClassPathXmlApplicationContext("spring-config.xml");
Customer cust = (Customer)ac.getBean("Customer");

System.out.println("The Values of Customer are:");
System.out.println(cust.getFirstName());
System.out.println(cust.getMiddleName());
System.out.println(cust.getLastName());


    }
}
