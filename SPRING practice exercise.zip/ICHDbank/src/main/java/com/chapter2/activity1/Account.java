package com.chapter2.activity1;

import java.io.Serializable;

public class Account implements Serializable {
private String accountNumber;
private String accountCreationdate;
private double balance;
private String accountType;

public Account() {
	
}

public Account(String accountNumber, String accountCreationdate, double balance, String accountType) {
	super();
	this.accountNumber = accountNumber;
	this.accountCreationdate = accountCreationdate;
	this.balance = balance;
	this.accountType = accountType;
}
public String getAccountNumber() {
	return accountNumber;
}
public void setAccountNumber(String accountNumber) {
	this.accountNumber = accountNumber;
}
public String getAccountCreationdate() {
	return accountCreationdate;
}
public void setAccountCreationdate(String accountCreationdate) {
	this.accountCreationdate = accountCreationdate;
}
public double getBalance() {
	return balance;
}
public void setBalance(double balance) {
	this.balance = balance;
}
public String getAccountType() {
	return accountType;
}
public void setAccountType(String accountType) {
	this.accountType = accountType;
}

}
