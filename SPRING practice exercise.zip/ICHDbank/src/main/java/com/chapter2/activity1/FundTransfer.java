package com.chapter2.activity1;

import java.io.Serializable;

public class FundTransfer implements Serializable {
private double amount;
public FundTransfer() {
	
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
	 
}
