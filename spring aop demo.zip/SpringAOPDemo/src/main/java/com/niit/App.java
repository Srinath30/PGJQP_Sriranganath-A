package com.niit;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.niit.model.Student;
import com.niit.service.StudentService;

public class App 
{
    public static void main( String[] args )
    {
    	ApplicationContext applicationContext = new ClassPathXmlApplicationContext("spring-config.xml");
    	Student student = (Student) applicationContext.getBean("student");
    	StudentService studentService=(StudentService) applicationContext.getBean("studentService");
    	studentService.setStudent(student);
    	System.out.println(studentService.getStudent().getStudentName());
    }
}

