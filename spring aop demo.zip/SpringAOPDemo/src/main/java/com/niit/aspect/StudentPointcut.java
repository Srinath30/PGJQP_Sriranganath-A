package com.niit.aspect;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class StudentPointcut {
	   @Before("getStudentNamePointcut())")
	   public void secondAdvice() 
	   {
		   System.out.println("we are executing secondAdvice on getStudentName() method");
	   }
	   @Pointcut("execution(public String getStudentName())")
	   public void getStudentNamePointcut() 
	   {
		   System.out.println("This is getStudentNamePointcut() method");
	   }
	   @Before("allMethodPointcut()")
	   public void thirdAdvice() 
	   {
		   System.out.println("we are executing third advice on all methods, using second pointcut");
	   }
	   @Pointcut("within(com.niit.service.*)")
	   public void allMethodPointcut() 
	   {
		
	   }
}
